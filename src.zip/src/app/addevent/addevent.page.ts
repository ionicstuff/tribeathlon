import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addevent',
  templateUrl: './addevent.page.html',
  styleUrls: ['./addevent.page.scss'],
})
export class AddeventPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
