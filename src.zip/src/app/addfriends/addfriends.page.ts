import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addfriends',
  templateUrl: './addfriends.page.html',
  styleUrls: ['./addfriends.page.scss'],
})
export class AddfriendsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
