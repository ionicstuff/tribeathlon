import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchevent',
  templateUrl: './searchevent.page.html',
  styleUrls: ['./searchevent.page.scss'],
})
export class SearcheventPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
