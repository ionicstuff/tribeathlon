import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewfriends',
  templateUrl: './viewfriends.page.html',
  styleUrls: ['./viewfriends.page.scss'],
})
export class ViewfriendsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
