import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-joinedevents',
  templateUrl: './joinedevents.page.html',
  styleUrls: ['./joinedevents.page.scss'],
})
export class JoinedeventsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
